export default function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <a href="#beranda" className="flex items-center gap-2.5 shrink-0" aria-label="TeknisiPintar - Beranda">
      <span
        className={`font-brand font-extrabold leading-none tracking-tight ${compact ? 'text-xl' : 'text-[22px]'}`}
      >
        <span className="text-[#0b46c8]">#Teknisi</span>
        <span className="text-[#03c9a8]">Pintar</span>
      </span>
      {!compact && (
        <span className="hidden sm:block text-[9px] font-bold leading-[1.15] tracking-[0.14em] text-[#0a1140] border-l-2 border-[#0b46c8]/30 pl-2.5">
          KOMUNITAS
          <br />
          TEKNISI INDONESIA
        </span>
      )}
    </a>
  )
}
